<?php

// Return nothing
RestUtility::sendResponse(200, '', $format);