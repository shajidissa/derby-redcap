<?php
/*****************************************************************************************
**  REDCap is only available through a license agreement with Vanderbilt University
******************************************************************************************/


/**
 * RepeatInstance Class
 */
class RepeatInstance
{
	
	// Return HTML for setup table for repeat instances
	public static function renderSetup()
	{
		global $lang, $Proj, $longitudinal;
		
		// Get array of repeating forms/events
		$RepeatingFormsEvents = $Proj->getRepeatingFormsEvents();

		// Get content for the setup table
		$row_data = array();
		if ($longitudinal) {
			// Each table row is an event
			foreach ($Proj->eventInfo as $this_event_id=>$attr) {
				// Is event already repeating?
				if (isset($RepeatingFormsEvents[$this_event_id])) {
					$selectedValue = is_array($RepeatingFormsEvents[$this_event_id]) ? 'PARTIAL' : 'WHOLE';
				} else {
					$selectedValue = '';
				}
				// Show form divs?
				$formHideClass = ($selectedValue == 'PARTIAL') ? '' : 'hide';
				// Build box of all forms designated for this event
				$eventForms = "";
				foreach ($Proj->eventsForms[$this_event_id] as $form) 
				{
					// Is this form checked?
					$checkboxChecked = isset($RepeatingFormsEvents[$this_event_id][$form]) ? 'checked' : '';
					// Build div for this form
					$eventForms .= 	RCView::div(array('class'=>"$formHideClass repeat_event_form_div repeat_event_form-$this_event_id repeat_event_form-$this_event_id-$form"),
										RCView::checkbox(array('name'=>"repeat_event_form-$this_event_id-$form", 'class'=>'repeat_event_form_chkbox', 'disabled'=>'disabled', $checkboxChecked=>$checkboxChecked)) .
										RCView::span(array('style'=>'vertical-align:middle;'), strip_tags($Proj->forms[$form]['menu']))
									);
				}
				// Add event to array
				$row_data[] = array(
								RCView::div(array('class'=>'repeat_event_label wrap'), strip_tags($attr['name_ext'])), 
								RCView::select(array('name'=>"repeat_whole_event-$this_event_id", 'disabled'=>'disabled', 'class'=>'x-form-text x-form-field repeat_select repeat_select_disabled', 
									'onchange'=>"showEventRepeatingForms(this,$this_event_id);"), 
									array(''=>'', 'WHOLE'=>$lang['setup_151'], 'PARTIAL'=>$lang['setup_152']), $selectedValue) .
								RCView::div(array('class'=>'repeat_event_forms_box'), $eventForms)
							);
			}
		} else {
			// Each table row is an instrument
			foreach ($Proj->forms as $form=>$attr) {
				// Is instrument already repeating?
				$checked = isset($RepeatingFormsEvents[$Proj->firstEventId][$form]);
				$checkboxChecked = $checked ? 'checked' : '';
				$imgChecked = $checked ? RCView::img(array('src'=>'tick.png', 'class'=>'repeat_checkbox')) : '';
				// Add instrument to array
				$row_data[] = array(
								RCView::div(array('class'=>'repeat_event_label wrap', 'style'=>'font-size:13px;'), strip_tags($attr['menu'])), 
								RCView::checkbox(array('name'=>"repeat_form-$form", 'class'=>'repeat_tick hide', $checkboxChecked=>$checkboxChecked)) .
								$imgChecked
							);
			}
		}

		// Set parameters for the setup table
		$col_widths_headers = array();
		if ($longitudinal) {
			$col_widths_headers[] = array(170, RCView::b($lang['global_10']));
			$col_widths_headers[] = array(350, RCView::div(array('class'=>'wrap', 'style'=>'font-weight:bold;padding: 5px 2px;'), $lang['setup_149']));
			$width = 540;
		} else {
			$col_widths_headers[] = array(270, RCView::b($lang['design_244']));
			$col_widths_headers[] = array(80, RCView::div(array('class'=>'wrap', 'style'=>'padding: 5px 0;'), $lang['setup_148']), 'center');
			$width = 370;
		}
		$title = RCView::div(array('style'=>'margin:0;'),
					RCView::button(array('id'=>'begin_btn', 'class'=>'jqbuttonmed', 'onclick'=>"beginBtnClick();return false;"), $lang['designate_forms_11']) . RCView::SP . 
					RCView::button(array('id'=>'save_btn', 'class'=>'jqbuttonmed', 'onclick'=>"saveBtnClick();return false;", 'disabled'=>'disabled'), $lang['designate_forms_13']) .
					RCView::span(array('id'=>'progress_span', 'style'=>'color:#555;visibility:hidden;margin-left:30px;font-weight:normal;font-family:arial;font-size:12px;'), 
						RCView::img(array('src'=>'progress_circle.gif', 'style'=>'margin-right:2px;')) .
						$lang['designate_forms_21']
					)
				 );

		// Build the setup table
		$html = RCView::form(array('id'=>'repeat_instance_setup_form'),
					renderGrid("repeat_setup", $title, $width, 'auto', $col_widths_headers, $row_data, true, false, false)
				);
		// Return the HTML
		return $html;
	}
	
	// Save settings from setup table for repeat instances
	public static function saveSetup()
	{
		global $Proj, $longitudinal;
		// Loop through post data
		if ($longitudinal) {
			## LONGITUDINAL
			foreach ($_POST as $key=>$val) {
				// Make sure it starts with repeat-form
				$pos = strpos($key, "repeat_whole_event-");
				if ($pos !== 0) continue;
				// Get event_id and validate it
				$event_id = substr($key, 19);
				if (!isset($Proj->eventInfo[$event_id])) continue;
				// First, remove any for this event_id in case any rows already exist
				$sql_all[] = $sql = "delete from redcap_events_repeat where event_id = $event_id";
				db_query($sql);
				// Make sure we only add the non-blank ones submitted
				if ($val != 'PARTIAL' && $val != 'WHOLE') continue;
				// Determine what to add
				if ($val == 'WHOLE') {
					// Add entire event (with null form_name)
					$sql_all[] = $sql = "insert into redcap_events_repeat (event_id, form_name) values ($event_id, null)";
					db_query($sql);
				} else {
					// Loop through all of this event's forms to see if they were submitted
					foreach ($Proj->eventsForms[$event_id] as $form) {
						// Was this form submitted?
						if (!isset($_POST["repeat_event_form-$event_id-$form"])) continue;
						// Add event-form to table
						$sql_all[] = $sql = "insert into redcap_events_repeat (event_id, form_name) values ($event_id, '".prep($form)."')";
						db_query($sql);
					}
				}
			}
		} else {
			## CLASSIC
			// Add all forms to array so we know
			$AddRepeating = array();
			// Get array of repeating forms/events
			$RepeatingFormsEvents = $DeleteRepeating = $Proj->getRepeatingFormsEvents();
			foreach ($_POST as $key=>$val) {
				// Make sure it starts with repeat-form
				$pos = strpos($key, "repeat_form-");
				if ($pos !== 0) continue;
				// Get form_name and validate it
				$form = substr($key, 12);
				if (!isset($Proj->forms[$form])) continue;
				// If not already set, then set to be repeating
				if (!isset($RepeatingFormsEvents[$Proj->firstEventId][$form])) {
					$AddRepeating[$Proj->firstEventId][$form] = true;
				}
				// Make sure we remove from DeleteRepeating
				unset($DeleteRepeating[$Proj->firstEventId][$form]);
			}
			// Remove any empty events in $DeleteRepeating
			if (!empty($DeleteRepeating)) {
				foreach ($DeleteRepeating as $event_id=>$forms) {
					if (empty($forms)) unset($DeleteRepeating[$event_id]);
				}
			}
			// Remove from table
			$sql_all = array();
			foreach ($DeleteRepeating as $event_id=>$forms) {
				foreach (array_keys($forms) as $form) {
					$sql_all[] = $sql = "delete from redcap_events_repeat where event_id = $event_id and form_name = '".prep($form)."'";
					db_query($sql);
				}
			}
			// Add to table
			foreach ($AddRepeating as $event_id=>$forms) {
				foreach (array_keys($forms) as $form) {
					$sql_all[] = $sql = "insert into redcap_events_repeat (event_id, form_name) values ($event_id, '".prep($form)."')";
					db_query($sql);
				}
			}
		}
		// Logging
		if (!empty($sql_all)) {
			log_event(implode(";\n", $sql_all),"redcap_events_repeat","MANAGE",PROJECT_ID,"","Set up repeating instruments".($longitudinal ? "/events" : ""));
		}
		// Reset the array in $Proj so that it gets regenerated
		$Proj->RepeatingFormsEvents = null;
	}
	
	
	// Display all repeating forms tables for a given record
	public static function renderRepeatingFormsDataTables($record, $grid_form_status=array(), $locked_forms=array())
	{
		global $Proj, $longitudinal, $lang;
		// HTML to return
		$html = "";
		// If project has no repeating forms, then return nothing
		if (!$Proj->hasRepeatingForms()) return $html;
		// Gather field names of all custom form labels (if any)
		$custom_form_labels_all = "";
		foreach ($Proj->RepeatingFormsEvents as $event_id=>$forms) {
			if (!is_array($forms)) continue;
			$custom_form_labels_all .= " " . implode(" ", $forms);
		}
		$custom_form_label_fields = $piped_data = array();
		if (trim($custom_form_labels_all) != "") {
			$custom_form_label_fields = array_keys(getBracketedFields($custom_form_labels_all, true, false, true));
			// Get piping data for this record
			$piped_data = Records::getData('array', $record, $custom_form_label_fields, array_keys($Proj->RepeatingFormsEvents));
		}
		// Loop through all repeating forms and build each as a table
		foreach ($Proj->RepeatingFormsEvents as $event_id=>$forms) 
		{
			// If this is an entire repeating event, then skip it
			if (!is_array($forms)) continue;
			// Loop through forms
			foreach ($forms as $form=>$custom_repeating_form_label) 
			{
				// If record-event-form does not have multiple instances of data yet, then skip
				if (count($grid_form_status[$event_id][$form]) <= 1) continue;
				// Obtain all repeating data for this record-event-form
				$instances = Records::getRepeatFormInstanceList($record, $event_id, $form);
				if (empty($instances)) continue;
				// Loop through instances
				$rows = "";
				foreach ($instances as $instance=>$form_status) 
				{
					// Determine color of button based on form status value
					switch ($form_status) {
						case '1':
							$status_icon = 'circle_yellow.png';
							break;
						case '2':
							$status_icon = 'circle_green.png';
							break;
						case '3':
							$status_icon = 'circle_orange_tick.png';
							break;
						case '4':
							$status_icon = 'circle_green_tick.png';
							break;
						default:
							$status_icon = 'circle_red.png';
					}
					//Display lock icon for any forms that are locked for this record
					$lockIcon = "";
					if (isset($locked_forms[$event_id.",".$form.",".$instance])) {
						$lockIcon = RCView::SP . $locked_forms[$event_id.",".$form.",".$instance];
					}
					// Pipe any custom form labels
					if ($custom_repeating_form_label != "") {
						$colspan = 3;
						$tableClass = 'col-xs-9 col-sm-6 col-md-4 col-lg-3';
						$pipedLabel = RCView::td(array('class'=>'data'),
										Piping::replaceVariablesInLabel($custom_repeating_form_label, $record, $event_id, $instance, $piped_data, false, null, false, $form)
									  );
					} else {
						$colspan = 2;
						$tableClass = 'col-xs-6 col-sm-4 col-md-2 col-lg-2';
						$pipedLabel = "";
					}
					// Output row
					$rows .= RCView::tr('',
								RCView::td(array('class'=>'labelrc text-center'), 
									$instance
								) .
								RCView::td(array('class'=>'data', 'style'=>'padding:2px 2px 2px 10px;'), 
									RCView::a(array('href'=>APP_PATH_WEBROOT."DataEntry/index.php?pid=".PROJECT_ID."&page=$form&id=".urlencode($record)."&event_id=$event_id&instance=$instance"),
										RCView::img(array('src'=>$status_icon, 'style'=>'')) .
										$lockIcon
									)
								) .
								$pipedLabel
							 );
				}
				// Add extra row with ADD button
				$rows .= RCView::tr('',
							RCView::td(array('class'=>'data text-center', 'style'=>'padding:5px;', 'colspan'=>$colspan),
								RCView::button(array('class'=>'btn btn-default btnAddRptEv opacity50', 'style'=>'font-size:12px !important;padding: 2px 6px !important;',
									'onclick'=>"window.location.href='".APP_PATH_WEBROOT."DataEntry/index.php?pid=".PROJECT_ID."&id=".urlencode($record)."&event_id=$event_id&page=$form&instance=".($instance+1)."';"), 
									"+ ".$lang['data_entry_247'])
							)
						 );
				// Add table
				$html .= RCView::div(array('class'=>$tableClass), 
							RCView::table(array('class'=>'form_border'), 
								RCView::th(array('class'=>'header', 'style'=>'background-color:#ddd;', 'colspan'=>$colspan), 
									RCView::escape($Proj->forms[$form]['menu']) .
									(!$longitudinal ? "" :
										RCView::div(array('style'=>'color:#800000;font-size:11px;font-weight:normal;'), 
											RCView::escape($Proj->eventInfo[$event_id]['name_ext'])
										)
									)
								) .
								$rows
							)
						 );
			}
		}
		// Add div wrapper
		$title = ($html == '') ? '' : RCView::div(array('id'=>'repeating_forms_table_parent_title'), $lang['grid_45']);
		$html = $title .
				RCView::div(array('id'=>'repeating_forms_table_parent', 'class'=>'container-fluid'), 
					$html
				);
		// Return html
		return $html;
	}
	
}